%nome do arquivo: exemplo_const_12_lajeN.m
%restri��es do exemplo_12
%Aluno: Pedro Kitawara
%trabalho de conclus�o de curso
%Este arquivo cont�m as restri��es n�o-lineares
% g - restri��es n�o lineares de desigualdade
% h  restri��es n�o lineares de igualdade

function [g,h] = exemplo_nolinear_constrains_12_lajeN(x)
% ---
% RENOMEANDO AS VARI�VEIS DE PROJETO
% ---
x1=x(1);%x2=x(2);
[C1,C2,rhostell,fck,gamac,fyk,gamas,gamaconc,gamacp,gamaforro,ecp,eforro,cargapiso,lx,ly,c,di,bw,bf,hf,q,gamaG,gamaQ] = dados_exemplo_12_N;
% ---
% DADOS DOS MATERIAIS
% ---
%CONCRETO
%fck = 35; %MPA RESIST�NCIA CARACTER�STICA DO CONCRETO
%gamac = 1.4; %coeficiente de minora��o do concreto
fcd = (fck*1000)/gamac; %MPa
%NOTA PARA SA�DA EM METROS PRECISA MULTIPLICAR O FCK POR 1000

% ---
% A�O
% ---
fyd = fyk/gamas; %MPa

% ---
% PESO ESPEC�FICO DOS MATERIAIS - NBR 6120
% ---

% ---
% SE��O
% ---
dlinha = c + 0.5*di; %m altura �til
d = x1 - dlinha; %altura �til

% ---
% COEFICIENTES DOS CARREGAMENTOS
% ---
gamaG = 1.4;
gamaQ = 1.4;

% --- 
% CARREGAMENTO �LTIMO
% ---
area = (hf*bf) + (x1-hf)*bw; %m2
g1 = gamaconc*area; %carga por metro da viga t [kN/m/nervura
g2 = gamacp*ecp;
g3 = gamaforro*eforro;
g4 = cargapiso;
qlinha = q*bf;
gt = (g1 + g2 + g3 + g4)*bf;
p = gamaG*gt + gamaQ*qlinha;

% ---
% �REA DE ARMADURA
% ---
%desc = 5/10; %di�metro da armadura em cm
%as =(pi*(des^2))/2;

% ---
% MOMENTO SOLICITANTE
% ---
msoc = (p*(lx^2))/8;

% ---
% EQUACIONAMENTO DO CONCRETO
% ---
% Devido as particularidades do dimensionamento da viga 't' teremos que ter
% duas situa��es de caso:

% ---
% CASO A
% ---
ma = 0.25092*d^2*bw*fcd;
%asa = (0.306*bf*(d))/fyd;

% ---
% CASO B
% ---
mb1 = (bf-bw)*hf*0.85*fcd*(d-(0.5*hf));
mb2 = 0.5576*bw*fcd*d;
mbtotal = mb1 + mb2;
%asb1 = (bf-bw)*hf*0.85*fcd/fyd; 
%asb2 = 0.68*bw*fcd/fyd;

% ---
% �REA DE A�O
% ---
%VIGOTA TB-6545
%TABELA BELGO GRUPO ARCELOR
%dinf = 5/10;
%as = 2*(pi*dinf^2/4);

% ---
% PAR�METRO DE LINHA NEUTA
% ---
%colocar a equa��o da linha neutra
%constante de c�lculo
cte1 = 0.68*d;
cte2 = (cte1)^2;
cte3 = 1.088*(msoc/(bf*fcd));
cte4 = cte2 - cte3;
cte5 = sqrt(cte4);

%xpos
xpos = (cte1 + cte5)/0.554;

%xneg
xneg = (cte1 - cte5)/0.554;

%ypos
ypos = 0.8*xpos;

%yneg
yneg = 0.8*xneg;
%

% ---
% ESCOLHENDO O VALOR DO "X"
% ---
if ypos > 0 && xpos <= x1
    xesc = ypos;
else
    %disp('ypos: Fora da se��o da viga "t"');
end

if yneg > 0 && yneg <= x1
    xesc = yneg;
else
    %disp('yneg: Fora da se��o da viga "t"');
end

disp(['yesc (m) = ' num2str(xesc)])

% ---
% VERIFICA��O DO CASO DE DIMENSIONAMENTO
% ---
if xesc <= hf
    %CASO A
    %RESTRI��ES DE DESIGUALDADE CASO A
    disp('CASO A');
    h(1) = msoc - ma;
else
    %CASO B
    %RESTRI��ES DE DESIGUALDADE CASO B
    disp('CASO B')
    h(1) = msoc - mbtotal;
    %VERIFICAR ESSA EQUA��O
    %h(2) = as - ((mb1/(fyd(d-0.5*hf)))-(mb2/(fyd*(d-xesc))));
end

g = [];

%
end